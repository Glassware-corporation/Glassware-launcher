#include <iostream>
#include <fstream>

void fixGWSF(std::string whatFile);
void endProgram(int exitCode);