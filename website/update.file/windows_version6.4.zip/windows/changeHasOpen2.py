fileChange = open("gwsf/hasOpened.gwsf", "w")
fileChange.write("0")
fileChange.close()
