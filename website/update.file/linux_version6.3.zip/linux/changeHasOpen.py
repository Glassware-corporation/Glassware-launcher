fileChange = open("gwsf/hasOpened.gwsf", "w")
fileChange.write("1")
fileChange.close()
